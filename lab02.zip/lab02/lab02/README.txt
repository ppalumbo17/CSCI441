CSCI441, Computer Graphics, Fall 2016
Dr. Jeffrey paone

Code Example: Lab02

	This program is a simple example of a flight simulator using a free camera
    model.  The user can move the camera through a city scene as if flying an airplane.

Usage: 
    Pressing 'w' moves the camera forward and pressing 's' moves the camera back.

    Left click and dragging the mouse moves the camera around.

    The user can also press the 'q' key to quit the program.

Compilation Instructions:
    Simply navigate to the directory and type 'make.' Only main.cpp needs
    to be linked with the OpenGL / freeglut libraries.

Notes:
