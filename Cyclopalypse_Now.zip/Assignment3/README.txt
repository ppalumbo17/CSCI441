CSCI441, Computer Graphics, Fall 2016
Peter Palumbo
Assignment 3

This code sucks. 
This project was frustrating.
I'm trying to submit this on time wish me luck.
Sorry this readme sucks.

The boundry works sometimes.
I promise the wheels actually spin.
The camera was confusing and I struggled with it a lot and it doesn't really work. But it follows the car around a bit.

The wasd keys should work.

Submitting now, I'm sorry.

