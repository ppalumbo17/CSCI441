CSCI441, Computer Graphics, Fall 2016
Peter Palumbo
Assignment 4

Description:  This program demonstrates the use of Bezier Curves by having a "Spirit" follow my Hero around on a Bezier curve that sticks with my Heros transport.

Usage: 
To move forward press w.
To move backkward press s.
To turn right press d.
To turn left press a.
To move the camera press the left mouse button and move the mouse.
To zoom the camera hold control and the left mouse button and move the mouse up and down.

Compiling:
To compile type make or gmake. Then run the executable named assignment4 with the argument of controlPoints7.csv.  If you have trouble compiling on windows see line 19 in main.cpp and change where it says include freeglut to include glut.

Bugs:
There is a bug where the car will stop moving when you get to the edge of the grid.  I've tried fixing this bug with a few different options but those fixes create other bugs.

Questions:
This assignment took me about 8 hours.
The lab before this assignment helped tremendously (9).
This assignment was a lot of fun.  I feel like the animations are getting more complex and it's cool. (7)

