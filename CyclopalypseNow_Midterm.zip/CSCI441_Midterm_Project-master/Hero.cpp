#include "Hero.h"
#include <math.h>
using namespace std;
/*
Hero::Hero() {

}

Hero::~Hero() {

}*/
void Hero::draw() {

}