#ifndef POINT_1
#define POINT_1
class Point {
	float x;
	float y;
	float z;
public:
	Point(float x, float y, float z);
	Point();

	float getDistance(Point p);
	float getX();
	float getY();
	float getZ();

	float getMagnitude();
		
};

Point operator*(Point p, float f); // multiplies a Point by a float
Point operator*(float f, Point p); // multiplies a float by a Point
Point operator+(Point a, Point b); // adds two Points together

#endif