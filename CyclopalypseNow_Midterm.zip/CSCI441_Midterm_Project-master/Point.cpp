#include <math.h>
#include "Point.h"
using namespace std;

Point::Point() {
	this->x = 1;
	this->y = 1;
	this->z = 1;
}
Point::Point(float x, float y, float z) {
	this->x = x;
	this->y = y;
	this->z = z;
}

Point operator* (float f, Point p)
{
	return Point(p.getX() * f, p.getY() * f, p.getZ() * f);
}

Point operator* (Point p, float f)
{
	return Point(p.getX() * f, p.getY() * f, p.getZ() * f);
}
Point operator+ (Point a, Point b)
{
	return Point(a.getX() + b.getX(), a.getY() + b.getY(), a.getZ() + b.getZ());
}

float Point::getDistance(Point p) {
	float xDist = this->x - p.getX();
	float yDist = this->y - p.getY();
	float zDist = this->z - p.getZ();

	// d = sqroot(x^2 + y^2 + z^2)
	return pow(pow(xDist, 2) + pow(yDist, 2) + pow(zDist, 2), .5);
}

float Point::getX() {
	return this->x;
}

float Point::getY() {
	return this->y;
}

float Point::getZ() {
	return this->z;
}

float Point::getMagnitude(){
	return sqrt(pow(this->x, 2)+pow(this->y, 2)+pow(this->z, 2));
}
//test
