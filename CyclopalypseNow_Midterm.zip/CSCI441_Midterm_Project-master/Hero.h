#ifndef HERO
#define HERO

class Hero {
public:
	
	//Hero();
	//~Hero();
	//virtual void draw();
	//virtual void draw() = 0;
	//virtual void animate() = 0;
	//virtual void moveForward() = 0;
	//virtual void moveBackward() = 0;
	//virtual void turnLeft() = 0;
	//virtual void turnRight() = 0; //
	//virtual float getCarX() = 0;
private:
	//int test;
};

#endif //