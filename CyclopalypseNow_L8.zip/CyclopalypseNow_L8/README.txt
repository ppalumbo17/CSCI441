Peter Palumbo / Cyclopalypse Now
Lab 08

Questions:
1) The teapot does not look like bricks
2) No other objects were textured.
3) Yep
4) Yep
5) Yep it reads right to left though
6) It only takes up a quarter quadrant
7) 5
8) The beginning of the write up was a little confusing
9) About 2 hours?
10) Nope