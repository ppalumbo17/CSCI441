CSCI441, Computer Graphics, Fall 2016
Peter Palumbo / Cyclopalypse Now

Code: Lab09

Questions: 
1) A uniform variable for GLSL is a variable that is the same between shaders and OpenGL.
2) An attribte variable for GLSL is a variable that is passed on a per-vertex basis.
3) We need not recompile the C++ code after we modify the GLSL code because it is used in conjunction with the cpp code.
4) It looks like that because the different quadrants represent different float values.
5) Uh... Yes? I'm still a bit confused but it probably just hasn't clicked quite yet.
6) This lab was interesting.
7) The write up for this lab was pretty good it got me to question just enough.
8) This lab took me about 2 hours.
9) Nope