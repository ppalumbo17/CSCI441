CSCI441, Computer Graphics, Fall 2016
Peter Palumbo / Cyclopalypse Now

Code: Assignment 5

Description: For Assignment 5 we worked with Shaders and implemented skyboxes.  This project allowed us to make our scene look much nicer
without putting a serious load on the hardware.

To run the program make it in the command line. Then pass in the files in this order: .exe, .csv (for spirit on curve), .obj, vertex.glsl, fragment.glsl

Bugs:  For some reason reading in the shader filenames wasn't working, they read in fine but then don't pass well to the createShader.
My car was having some trouble with gaining a material.  Also when I transfered over the assignment 4 code something weird happend with the camera, you can uncomment the lookAt if you'd like it gets kinda funky though.

Questions:

This assignment took about 10 hours.
The lab was very helpful for the assignment.
THis assignment was cool but not fun because it was so frustrating.


