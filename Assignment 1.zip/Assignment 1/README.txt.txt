Peter Palumbo / Cyclopalypse Now
Assignment 1 / Adorn Your Hero

This program creates my heros name using opengl primitives such as GL_TRIANGLES, and GL_QUADS.

To run this program cd into the folder in the terminal.  Run make or gmake.  Run .\lab00b.exe (Yes I used the makefile from the lab).

There shouldn't be any bugs.

The lab was a great help understanding how to do the very basics.

This assignment was the most fun I've had all semester! (So you know in like the last two weeks...)