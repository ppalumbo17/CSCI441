Peter Palumbo
Lab 1
Computer Graphics
September 2nd, 2016

I believe it is better to use global variables for these calls.  This way if you ever need to change one it is easy to find and easy to change.

Fun level: 6
Write-Up: There were some parts of the write up that were a little confusing.  Not quite enough hand holding I would say.
Length: This lab took me about an hour and a half to complete.
No Other Comments.