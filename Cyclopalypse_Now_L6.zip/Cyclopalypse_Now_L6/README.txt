CSCI441, Computer Graphics, Fall 2016
Peter Palumbo

Code Example: Lab06

	This program is the completed Lab02 Flight Simulator.  This is version
    0.33!  It will add lighting to make our scene look more realistic.

Usage: 
    Pressing 'w' moves the camera forward and pressing 's' moves the camera back.

    Left click and dragging the mouse moves the camera around.

    Ctrl + Left click will zoom the camera in/out from our plane.

    The user can also press the 'q' or ESC key to quit the program.

Compilation Instructions:
    Simply navigate to the directory and type 'make.' main.cpp needs
    to be linked with the OpenGL / freeglut libraries.  

Notes:
Questions:
Are the buildings near the teapot "brighter" than buildings near the edge?
No
Can you notice any lighting effects on the ground?
No
Now does the floor appear brighter near the center and darker near the edges?
Yes
Do you see a spotlight projecting from the plane? As you fly around, does the light
move with you?
No? Yes now they do
Do the edges of the spotlight seem softer?
No? Yes now they do

Q1: Sort of no (4)
Q2: Not quite enough
Q3: This lab took a few hours
Q4: Nope