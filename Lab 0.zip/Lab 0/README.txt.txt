Name: Peter Palumbo
Class: Computer Graphics CSCI441
Occupation: Hazardous
Date: 8/31/16

1) Was this lab fun?
Of course it was fun, I made a triforce! (6)

2) How was the write up for this lab?
I thought the write up was just write. I only had to ask one question so it must but good.

3)How long did this lab take?
This lab took me about an hour and a half.  I was fiddling with a lot of things though.

4) How many time can you push to the stack? pop?
You can push as many time as you want (theres a limit thats large).  You can also pop as much as you want, but there will always be one matrix on the stack (you get an unseen error).